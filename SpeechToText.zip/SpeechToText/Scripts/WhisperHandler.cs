// Whisper integration guided by https://github.com/Macoron/whisper.unity/blob/master/Assets/Samples/2%20-%20Microphone/MicrophoneDemo.cs
// -> Whisper has functionality to add ellipsis when the user pauses for too long while talking.

using System.Collections;
using System.Collections.Generic;
using UnityEngine;
using Whisper.Utils;

public class WhisperHandler : MonoBehaviour
{
    // Interfaces with the whisper library
    public Whisper.WhisperManager whisper;
    // Interfaces with a microphone recorder
    public MicrophoneRecord microphoneRecord;

    // Progress output
    public string progressPrefix = "Progress";
    string progressOutput = "";

    // Record output
    string recordOutput = "No Result";

    private void Awake()
    {
        // Bind whisper method
        whisper.OnProgress += OnProgressHandler;

        // Bind recording methods
        microphoneRecord.OnRecordStop += OnRecordStop;
    }

    // Starts a recording, returns early if a recording is already in progress
    public void OnRecordStart()
    {
        // Check if the microphone is recording
        if (microphoneRecord.IsRecording)
        {
            Debug.LogWarning("WhisperHandler -> Attempted to start recording while another is already in progress");
            return;
        }

        // Start a recording
        microphoneRecord.StartRecord();
    }

    // Stops a recording, returns early if there is no recording in progress
    public void OnRecordStop()
    {
        // Check if the microphone is not recording
        if (!microphoneRecord.IsRecording)
        {
            Debug.LogWarning("WhisperHandler -> Attempted to stop recording while nothing was recording");
            return;
        }

        // Stop a recording
        microphoneRecord.StopRecord();
    }

    // Processes audio recording
    private async void OnRecordStop(AudioChunk recordedAudio) 
    {
        // Process information from recorded audio
        var audioInfo = await whisper.GetTextAsync(recordedAudio.Data, recordedAudio.Frequency, recordedAudio.Channels);
        if (audioInfo == null)
            return;

        // Set recorded output
        recordOutput = audioInfo.Result;
        // Trigger Delegate
        onRecordingProcessed?.Invoke(recordOutput);
    }

    // Delegate to send out text after being processed
    public delegate void OnRecordingProcessed(string text);
    public OnRecordingProcessed onRecordingProcessed;

    // Returns transcript of the recording
    public string GetRecordOutput()
    {
        return recordOutput;
    }

    // Displays the time it takes to process voice
    private void OnProgressHandler(int progress)
    {
        progressOutput = $"{progressPrefix}: {progress}";
    }

    // Get the progress output
    public string GetProgressOutput()
    {
        return progressOutput;
    }
}
