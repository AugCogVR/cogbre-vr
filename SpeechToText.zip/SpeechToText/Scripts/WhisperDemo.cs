using System.Collections;
using System.Collections.Generic;
using UnityEngine;
using UnityEngine.UI;
using TMPro;

public class WhisperDemo : MonoBehaviour
{
    // Interface with the whisper handler
    public WhisperHandler whisperHandler;

    // Speech Text
    public TextMeshProUGUI speechText;

    // Record Button
    public Button recordButton;
    public TextMeshProUGUI buttonText;

    // Bind Method to button/handler
    private void Awake()
    {
        recordButton.onClick.AddListener(OnRecordToggled);
        whisperHandler.onRecordingProcessed += UpdateSpeechText;
    }

    // Toggle recording
    bool recording = false;
    private void OnRecordToggled()
    {
        // Run method from handler based on recording state
        // -> Start Recording
        if (!recording)
        {
            buttonText.text = "Stop";
            whisperHandler.OnRecordStart();
            recording = true;
        }
        // -> Stop Recording
        else
        {
            buttonText.text = "Record";
            whisperHandler.OnRecordStop();
            recording = false;
        }
    }

    // Update speech text
    public void UpdateSpeechText(string text)
    {
        speechText.text = text;
    }
}
