============================
Drag and Drop the unity package into a project to import.
The unity package includes the following assets. These will be automatically injected into the following paths (in the unity Assets folder). 
ANY FILES WITH THE SAME PATH MAY BE OVERWRITTEN

/Scenes/WhisperTest // This is a scene I put together to test out the Whisper Package, it also has an example for the structure of the script Whisper Handler
/SpeechTextDemo/WhisperDemo.cs // This script handles the buttons on the test scene
/SpeechTextDemo/WhisperHandler.cs // This script interfaces with Whisper
/StreamingAssets/Whisper/ggml-tiny.bin // This is the Whisper Model Path (Seen in Whisper Manager)

============================
You will also need to import the following GIT URL into the Package Manager.

https://github.com/Macoron/whisper.unity.git?path=/Packages/com.whisper.unity

============================
Ensure that Text Mesh Pro is imported into the project (it should be) before opening the scene WhisperTest

============================